package com.ideas2it.employeeManagement.employee.service;

import com.ideas2it.employeeManagement.department.departmentDTO.DepartmentDTO;
import com.ideas2it.employeeManagement.employee.employeeDTO.EmployeeDTO;
import com.ideas2it.employeeManagement.employee.respository.EmployeeRepository;
import com.ideas2it.employeeManagement.mapper.DepartmentMapper;
import com.ideas2it.employeeManagement.mapper.EmployeeMapper;
import com.ideas2it.employeeManagement.mapper.ProjectMapper;
import com.ideas2it.employeeManagement.model.Department;
import com.ideas2it.employeeManagement.model.Employee;
import com.ideas2it.employeeManagement.model.Project;
import com.ideas2it.employeeManagement.project.projectDTO.ProjectDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * <p>
 * Service class that provides business logic related to Employee operations.
 * This class acts as an intermediary between the controller layer and the repository layer.
 * It contains methods for creating, retrieving, updating, and deleting Employee entities.
 * The service ensures that the necessary business rules are applied before data
 * is persisted or retrieved from the database.
 * </p>
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public EmployeeDTO createEmployee(EmployeeDTO employeeDTO) {
        return EmployeeMapper.convertToDTO(employeeRepository.save(EmployeeMapper
                .convertToEntity(employeeDTO)));
    }

    @Override
    public EmployeeDTO getEmployeeById(Long id) {
        Optional<Employee> employeeOptional = employeeRepository
                .findByEmployeeIdAndIsDeletedFalse(id);
        return EmployeeMapper.convertToDTO(employeeOptional
                .orElseThrow(() -> new RuntimeException("Employee not found for ID: " + id)));
    }

    @Override
    public List<EmployeeDTO> getAllEmployees() {
        List<EmployeeDTO> employeeDTOs = new ArrayList<>();
        List<Employee> employees = employeeRepository.findByIsDeletedFalse();
        for (Employee employee : employees) {
            employeeDTOs.add(EmployeeMapper.convertToDTO(employee));
        }
        return employeeDTOs;
    }

    @Override
    public EmployeeDTO updateEmployee(Long id, EmployeeDTO employeeDTO) {
        Employee excistingEmployee = employeeRepository.findByEmployeeIdAndIsDeletedFalse(id)
                .orElseThrow(() -> new RuntimeException("Employee not found for ID: " + id));
        excistingEmployee.setEmployeeName(EmployeeMapper.convertToEntity(employeeDTO).getEmployeeName());
        excistingEmployee.setPlace(EmployeeMapper.convertToEntity(employeeDTO).getPlace());
        excistingEmployee.setDateOfBirth(EmployeeMapper.convertToEntity(employeeDTO).getDateOfBirth());
        excistingEmployee.setSalary(EmployeeMapper.convertToEntity(employeeDTO).getSalary());
        excistingEmployee.setExperience(EmployeeMapper.convertToEntity(employeeDTO).getExperience());
        return EmployeeMapper.convertToDTO(employeeRepository.save(EmployeeMapper.convertToEntity(employeeDTO)));
    }

    @Override
    public void deleteEmployee(Long id) {
        Employee employee = EmployeeMapper.convertToEntity(getEmployeeById(id));
        employee.setDeleted(true);
        employeeRepository.save(employee);
    }

    @Override
    public EmployeeDTO assignEmployeeToDepartment(EmployeeDTO employeeDTO, DepartmentDTO departmentDTO) {
        Employee employee = EmployeeMapper.convertToEntity(employeeDTO);
        Department department = DepartmentMapper.convertToEntity(departmentDTO);
        employee.setDepartment(department);
        employeeRepository.save(employee);
        return EmployeeMapper.convertToDTO(employee);
    }

    @Override
    public EmployeeDTO assignEmployeeToProject(EmployeeDTO employeeDTO, ProjectDTO projectDTO) {
        Employee employee = EmployeeMapper.convertToEntity(employeeDTO);
        Project project = ProjectMapper.convertToEntity(projectDTO);
        List<Project> projects = employee.getProjects();
        projects.add(project);
        employee.setProjects(projects);
        employeeRepository.save(employee);
        return EmployeeMapper.convertToDTO(employee);
    }
}

