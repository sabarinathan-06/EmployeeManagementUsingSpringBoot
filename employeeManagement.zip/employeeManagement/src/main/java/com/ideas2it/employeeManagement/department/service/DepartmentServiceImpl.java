package com.ideas2it.employeeManagement.department.service;

import com.ideas2it.employeeManagement.department.departmentDTO.DepartmentDTO;
import com.ideas2it.employeeManagement.mapper.DepartmentMapper;
import com.ideas2it.employeeManagement.model.Department;
import com.ideas2it.employeeManagement.department.respository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class DepartmentServiceImpl implements DepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;

    @Override
    public DepartmentDTO createDepartment(DepartmentDTO departmentDTO) {
        return DepartmentMapper.convertToDTO(departmentRepository
                .save(DepartmentMapper.convertToEntity(departmentDTO)));
    }

    @Override
    public DepartmentDTO getDepartmentById(Long id) {
        Optional<Department> departmentOptional = departmentRepository
                .findByDepartmentIdAndIsDeletedFalse(id);
        return DepartmentMapper.convertToDTO(departmentOptional
                .orElseThrow(() -> new RuntimeException("Department not found for ID: " + id)));
    }

    @Override
    public List<DepartmentDTO> getAllDepartments() {
        List<DepartmentDTO> departmentDTOs = new ArrayList<>();
        List<Department> departments = departmentRepository.findByIsDeletedFalse();
        for (Department department : departments) {
            departmentDTOs.add(DepartmentMapper.convertToDTO(department));
        }
        return departmentDTOs;
    }

    @Override
    public DepartmentDTO updateDepartment(Long id, DepartmentDTO departmentDTO) {
        Department department = DepartmentMapper.convertToEntity(getDepartmentById(id));
        department.setDepartmentName(departmentDTO.getDepartmentName());
        return DepartmentMapper.convertToDTO(departmentRepository.save(department));
    }

    @Override
    public void deleteDepartment(Long id) {
        Department department = DepartmentMapper.convertToEntity(getDepartmentById(id));
        department.setDeleted(true);
        departmentRepository.save(department);
    }
}
