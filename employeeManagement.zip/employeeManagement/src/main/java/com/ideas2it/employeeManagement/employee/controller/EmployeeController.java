package com.ideas2it.employeeManagement.employee.controller;

import com.ideas2it.employeeManagement.department.departmentDTO.DepartmentDTO;
import com.ideas2it.employeeManagement.employee.employeeDTO.EmployeeDTO;
import com.ideas2it.employeeManagement.department.service.DepartmentService;
import com.ideas2it.employeeManagement.employee.service.EmployeeService;
import com.ideas2it.employeeManagement.project.projectDTO.ProjectDTO;
import com.ideas2it.employeeManagement.project.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for managing Employee-related operations.
 *
 * <p>
 * This controller handles HTTP requests and provides endpoints for
 * creating, retrieving, updating, and deleting Employee entities. The
 * controller maps client requests to the appropriate service methods
 * and returns responses in the form of JSON or other supported media types.
 * It is annotated with Spring MVC annotations to define the URL mappings
 * and request handling logic.
 * All responses are returned in a standardized format to ensure consistency across
 * the API.
 * </p>
 */
@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private DepartmentService departmentService;

    @Autowired
    private ProjectService projectService;

    /**
     * Creates a new employee.
     *
     * @param employeeDTO {@link EmployeeDTO} The DTO containing employee data.
     * @return The created employee DTO with HTTP status 201 Created.
     */
    @PostMapping
    public ResponseEntity<EmployeeDTO> createEmployee(@RequestBody EmployeeDTO employeeDTO) {
        try {
            EmployeeDTO createdEmployeeDto = employeeService.createEmployee(employeeDTO);
            return new ResponseEntity<>(createdEmployeeDto, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{id}")
    public EmployeeDTO getEmployeeById(@PathVariable Long id) {
        return employeeService.getEmployeeById(id);
    }

    @GetMapping
    public List<EmployeeDTO> getAllEmployees() {
        return employeeService.getAllEmployees();
    }

    @PutMapping
    public EmployeeDTO updateEmployee(@PathVariable Long id, @RequestBody EmployeeDTO employeeDTO) {
        return employeeService.updateEmployee(id, employeeDTO);
    }

    @DeleteMapping("/{id}")
    public void deleteEmployee(@PathVariable Long id) {
        employeeService.deleteEmployee(id);
    }

    @PutMapping("/{employeeId}/departments/{departmentId}")
    public EmployeeDTO assignEmployeeToDepartment(@PathVariable Long employeeId, @PathVariable Long departmentId) {
        EmployeeDTO employeeDTO = employeeService.getEmployeeById(employeeId);
        DepartmentDTO departmentDTO = departmentService.getDepartmentById(departmentId);
        return employeeService.assignEmployeeToDepartment(employeeDTO, departmentDTO);
    }

    @PutMapping("/{employeeId}/projects/{projectId}")
    public EmployeeDTO assignEmployeeToProject(@PathVariable Long employeeId, @PathVariable Long projectId) {
        EmployeeDTO employeeDTO = employeeService.getEmployeeById(employeeId);
        ProjectDTO projectDTO = projectService.getProjectById(projectId);
        if (employeeDTO != null && projectDTO != null) {
            return employeeService.assignEmployeeToProject(employeeDTO, projectDTO);
        } else {
            return null;
        }
    }
}