package com.ideas2it.employeeManagement.project.service;

import com.ideas2it.employeeManagement.mapper.ProjectMapper;
import com.ideas2it.employeeManagement.model.Project;
import com.ideas2it.employeeManagement.project.projectDTO.ProjectDTO;
import com.ideas2it.employeeManagement.project.respository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProjectServiceImpl implements ProjectService {

    @Autowired
    private ProjectRepository projectRepository;

    @Override
    public ProjectDTO createProject(ProjectDTO projectDTO) {
        return ProjectMapper.convertToDTO(projectRepository.save(ProjectMapper.convertToEntity(projectDTO)));
    }

    @Override
    public ProjectDTO getProjectById(Long id) {
        return ProjectMapper.convertToDTO(projectRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Project not found")));
    }

    @Override
    public List<ProjectDTO> getAllProjects() {
        List<ProjectDTO> projectDTOs = new ArrayList<>();
        List<Project> projects = projectRepository.findByIsDeletedFalse();
        for (Project project : projects) {
            projectDTOs.add(ProjectMapper.convertToDTO(project));
        }
        return projectDTOs;
    }

    @Override
    public ProjectDTO updateProject(Long id, ProjectDTO projectDTO) {
        Project project = ProjectMapper.convertToEntity(getProjectById(id));
        project.setProjectName(projectDTO.getProjectName());
        return ProjectMapper.convertToDTO(projectRepository.save(project));
    }

    @Override
    public void deleteProject(Long id) {
        Project project = ProjectMapper.convertToEntity(getProjectById(id));
        project.setDeleted(true);
        projectRepository.save(project);
    }
}
